import React, { Component } from 'react'

export class alunoForm extends Component {
  render() {
    return (
      <div>
        
      </div>
    )
  }
}

export default alunoForm
