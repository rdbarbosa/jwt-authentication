import React, { Component } from 'react'
import { FormGroup, ControlLabel, FormControl, HelpBlock, Radio, Button } from 'react-bootstrap'

export class Aluno extends Component {
  render() {
    return (
        <div>
            <form>
                <FormGroup controlId="formBasicText">
                    <ControlLabel>Nome</ControlLabel>
                    <FormControl type="text" placeholder="Enter text" />
                    <FormControl.Feedback />
                    <HelpBlock>Validation is based on string length.</HelpBlock>
                </FormGroup>
                <FormGroup controlId="formBasicText">
                    <ControlLabel>Sexo</ControlLabel>
                    <FormControl type="text" placeholder="Enter text" />
                </FormGroup>
                <FormGroup controlId="formBasicText">
                    <ControlLabel>Data de Nascimento</ControlLabel>
                    <FormControl type="text" placeholder="Enter text" />
                </FormGroup>
                <FormGroup>
                    <Radio name="radioGroup" inline>
                        Feminino
                    </Radio>{' '}
                    <Radio name="radioGroup" inline>
                        Masculino
                    </Radio>
                </FormGroup>
                <FormGroup controlId="formBasicText">
                    <ControlLabel>Nome da Mãe</ControlLabel>
                    <FormControl type="text" placeholder="Enter text" />
                </FormGroup>
                <FormGroup controlId="formBasicText">
                    <ControlLabel>e-mail</ControlLabel>
                    <FormControl type="email" placeholder="Enter text" />
                </FormGroup>
                <FormGroup controlId="formBasicText">
                    <ControlLabel>Telefone</ControlLabel>
                    <FormControl type="text" placeholder="Enter text" />
                </FormGroup>
                <FormGroup>
                    {/* <Col smOffset={2} sm={10}> */}
                        <Button type="submit">Sign in</Button>
                    {/* </Col> */}
                </FormGroup>
            </form>
        </div>
    )
  }
}

export default Aluno
