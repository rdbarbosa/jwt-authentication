import axios from 'axios'
// import { toastr } from 'react-redux-toastr'
import { reset as resetForm, initialize } from 'redux-form'

const BASE_URL = 'http://localhost:5000/api'
// const INITIAL_VALUES = { status: "", message: "", data:{ result: [{}]}, list: [{}] }

export const getList = () => dispatch =>  {
    const request = ''
    axios.get(`${BASE_URL}/pessoa`).then((res) => {
        console.log(res)
        dispatch({
            type: 'ALUNOS_FETCHED',
            payload: res.data
        });
    })
}

export const create = (values) => {
    submit(values, 'post')
}

export function update(values) {
    return submit(values, 'put')
}

export function remove(values) {
    return submit(values, 'delete')
}

function submit(values, method) {
    return dispatch => {
        const id = values._id ? values._id : ''
        axios[method](`${BASE_URL}/billingCycles/${id}`, values)
            .then(resp => {
                //toastr.success('Sucesso', 'Operação Realizada com sucesso.')
                dispatch(init())
            })
            .catch(e => {
                e.response.data.errors.forEach(error => console.log('Erro', error))
            })
    }
}

export function init() {
    return [
        //getList()
        //initialize('billingCycleForm', INITIAL_VALUES)
    ]
}