// const INITIAL_STATE = { status: "", message: "", data:{ result: [{}]}, list: [{}] }
const INITIAL_STATE = { list: [] }

const pessoa = [
    {
        nome: 'Aluno 1'
    },{
        nome: 'Aluno 2'
    },{
        nome: 'Aluno 3'
    }
]

export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case 'ALUNOS_FETCHED':
            return { ...state, list: action.payload.result }
        default:
            return state
    }
}