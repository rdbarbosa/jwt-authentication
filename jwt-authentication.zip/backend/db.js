module.exports = {
    DB: 'mongodb://dev:cpd*1234@ds031257.mlab.com:31257/dbhovi'
}